
# Interactive Voters Dashboard

## Run Locally
1. Install requirements:
pip install -r requirements.txt

2. Run app:
streamlit run app.py

## Deploy on Streamlit Cloud
1. Upload files to GitHub
2. Go to https://streamlit.io/cloud
3. Connect GitHub repository
4. Select app.py
5. Deploy
