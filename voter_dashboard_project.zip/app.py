
import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="Voters Dashboard", layout="wide")

# Load data
df = pd.read_csv("voters_data.csv")

# Title
st.title("Interactive Voters Dashboard")
st.markdown("### Analysis of Voter Statistics Across 5 Constituencies")

# Sidebar
st.sidebar.header("Filter Options")

constituency = st.sidebar.multiselect(
    "Select Constituencies",
    options=df["Constituency"].unique(),
    default=df["Constituency"].unique()
)

filtered_df = df[df["Constituency"].isin(constituency)]

# Metrics
total_voters = filtered_df["Registered_Voters"].sum()
avg_turnout = filtered_df["Turnout_Percentage"].mean()
total_polling = filtered_df["Polling_Stations"].sum()

col1, col2, col3 = st.columns(3)

col1.metric("Total Registered Voters", f"{total_voters:,}")
col2.metric("Average Turnout (%)", f"{avg_turnout:.1f}%")
col3.metric("Polling Stations", f"{total_polling:,}")

st.divider()

# Bar chart
fig1 = px.bar(
    filtered_df,
    x="Constituency",
    y="Registered_Voters",
    color="Constituency",
    title="Registered Voters by Constituency"
)

st.plotly_chart(fig1, use_container_width=True)

# Gender distribution
gender_df = filtered_df.melt(
    id_vars=["Constituency"],
    value_vars=["Male_Voters", "Female_Voters"],
    var_name="Gender",
    value_name="Count"
)

fig2 = px.pie(
    gender_df,
    values="Count",
    names="Gender",
    title="Gender Distribution"
)

st.plotly_chart(fig2, use_container_width=True)

# Youth voters chart
fig3 = px.line(
    filtered_df,
    x="Constituency",
    y="Youth_Voters",
    markers=True,
    title="Youth Voters by Constituency"
)

st.plotly_chart(fig3, use_container_width=True)

# Turnout chart
fig4 = px.scatter(
    filtered_df,
    x="Polling_Stations",
    y="Turnout_Percentage",
    size="Registered_Voters",
    color="Constituency",
    title="Turnout vs Polling Stations"
)

st.plotly_chart(fig4, use_container_width=True)

# Data table
st.subheader("Detailed Dataset")
st.dataframe(filtered_df)

# Download button
csv = filtered_df.to_csv(index=False).encode('utf-8')

st.download_button(
    label="Download Filtered Data",
    data=csv,
    file_name="filtered_voters_data.csv",
    mime="text/csv"
)
